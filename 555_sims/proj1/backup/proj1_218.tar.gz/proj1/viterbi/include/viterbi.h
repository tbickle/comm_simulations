#include <vector>
//#include "fsm.h"
using namespace std;
using namespace gr;
using namespace trellis;

//#ifndef BASE_H
//#define BASE_H

vector<int> VA_encode(fsm,vector<int>,int);
vector<int> int2bin(vector<int>,int);

//#endif

