#ifndef ADD_H
#define ADD_H

int add(int x, int y);

#endif
