g++ -c ./source/base.cpp -std=c++11
g++ -c ./source/fsm.cpp -std=c++11
g++ -c ./source/viterbi.cpp -std=c++11
g++ -c ./source/cc_test.cpp -std=c++11
g++ -o test base.o fsm.o viterbi.o cc_test.o
echo $(date) > ./notes/out
./test >> ./notes/out
./test

