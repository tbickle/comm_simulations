#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	// argc is the argument count
	// argv contains the arguments "2.2" and "5.4"
	cout << "argc: " << argc << endl;
	cout << "argv[]: " << argv[1] << endl;

	return 0;
}
